
<!DOCTPE html>
<html>
	<head>
		<meta charset="utf.8">
		<title> Robot </title>
		<link rel="stylesheet" herf="style.css" />

	<style>
		body{
			background: lightblue;
			font-size : 300% ;
			position:fixed;top : 10%; left: 8%;
		}
	</style>
	</head>
	<body>
	<?php
		require_once 'C:\Users\amals\Documents\Xampp\htdocs\Robot\dataConn.php';
        $result = "SELECT `Left` , `Right` , `Stop` , `Forward` , `Backward` FROM `directions`
				ORDER BY id DESC
				LIMIT 1";
				
			$query = mysqli_query($database, $result) or die (mysqli_error($database));
			while($row = mysqli_fetch_assoc($query)){
				foreach($row as $row){
					print "$row\t";
				}
			}
?>
	</body>
</html>

