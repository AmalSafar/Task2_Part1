<?php
 require_once 'C:\Users\amals\Documents\Xampp\htdocs\Robot\dataConn.php';
?>
<!DOCTPE html>
<html>
	<head>
		<meta charset="utf.8">
		<title> Robot </title>
		<link rel="stylesheet" herf="style.css" />
	</head>
	<body>
	
		<h1> Task 2 - insert on database </h1>
		<style>
		fieldset{background:lightgray;padding:40px;padding : 150px}
		legend{background:#FFF;border:2px solid#CCC;padding:5px;position:fixed; top: 7%; left: 39%;}
		input {width:100px}
		#Forward{position:fixed;top : 23%;left: 45%;width : 5%;padding : 10px;background:white;color: green;}
		#STOP{position:fixed;top : 32%;left: 45%;background:red;color: white;width:5%;padding : 10px ;}
		#BACK{position:fixed;top : 41%;left: 45%;width : 5%;padding : 10px ;background:white;color: green;}
		#LEFT{position:fixed;top : 32%;	left: 39%;width : 4%;padding : 10px ;background:white;color: green;}
		#RIGHT{position:fixed;top : 32%;left: 52%;width : 4%;padding : 10px ;background:white;color: green;}
	    div{position:fixed;top : 30%;left: 28%;}
		</style>
		<fieldset>
			<legend> Click on the button to move the robot  </legend>
			<form action="" method="POST">			
				<br>
				<button  id="Forward" type="submit" title="Forward" name="F" class="button">Forward</button>
				<br>
				<button  id="LEFT"	  type="submit" title="Left"    name="L" class="button" >Left</button>
				<button  id="RIGHT"   type="submit" title="Right"   name="R" class="button" >Right</button>
				<button  id="STOP"    type="submit" title="Stop"    name="S" class="button" >Stop</button>
				<br>
				<button  id="BACK" type="submit" title="Backward" name="B" class="button" >Backward</button>
				<br>
			</form>	
		</fieldset>
		<?php
        $result='';
		if(isset ($_POST["L"])){
			$result='L';
			$query = "INSERT INTO `directions` (`Left` , `Right` , `Stop` , `Forward` , `Backward`)VALUES( '$result' ,  ' ' , ' ' , ' ' , ' ' )";
			if(mysqli_query($database, $query)){
				echo("Move to the Left");
				
			}else{
				echo "Erorr: could not able to execute $query." . mysqli_error($database);
			}
			header('Location:DisplayDirection.php');
			mysqli_close($database);
		}
		if(isset ($_POST["R"])){
			$result='R';
			$query = "INSERT INTO `directions` (`Left` , `Right` , `Stop` , `Forward` , `Backward`)VALUES( ' ' , '$result' , ' ' , ' ' , ' ' )";
			if(mysqli_query($database, $query)){
				echo("Move to the Right");
			}else{
				echo "Erorr: could not able to execute $query." . mysqli_error($database);
			}
			header('Location:DisplayDirection.php');
			mysqli_close($database);
		}
	    
		if(isset ($_POST["S"])){
			$result='S';
			$query = "INSERT INTO `directions` (`Left` , `Right` , `Stop` , `Forward` , `Backward`)VALUES( ' ' , ' ' , '$result' , ' ' , ' ' )";
			
			if(mysqli_query($database, $query)){
				echo("Robot Stopped");
			}else{
				echo "Erorr: could not able to execute $query." . mysqli_error($database);
			}
			header('Location:DisplayDirection.php');
			mysqli_close($database);
		}
		if(isset ($_POST["F"])){
			
			$result='F';
			$query = "INSERT INTO `directions` (`Left` , `Right` , `Stop` , `Forward` , `Backward`)VALUES( ' ' , ' ' , ' ' , '$result' , ' ' )";
			
			if(mysqli_query($database, $query)){
				echo("Move Forward");
			}else{
				echo "Erorr: could not able to execute $query." . mysqli_error($database);
			}
			header('Location:DisplayDirection.php');
			mysqli_close($database);
		}
		if(isset ($_POST["B"])){
			$result='B';
			$query = "INSERT INTO `directions` (`Left` , `Right` , `Stop` , `Forward` , `Backward`)VALUES( ' ' , ' ' , ' ' , ' ' , '$result' )";
			
			if(mysqli_query($database, $query)){
				echo("Move Backward");
			}else{
				echo "Erorr: could not able to execute $query." . mysqli_error($database);
			}
			header('Location:DisplayDirection.php');
			mysqli_close($database);
		}
		
		?>
	</body>
</html>

