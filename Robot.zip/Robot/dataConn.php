<?php
 $user = 'root';
 $pass = '';
 $data = 'robot_directions';
 $database =  mysqli_connect('localhost' , $user , $pass , $data) or die ("Unable to connect");
?>